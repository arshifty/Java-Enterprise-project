
public class NetworkInfo {

}
