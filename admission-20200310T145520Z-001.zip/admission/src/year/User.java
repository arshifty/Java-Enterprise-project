package year;
public class User {

	
	private String fssc,lssc,fhsc,lhsc;

	int id;
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFssc() {
		return fssc;
	}

	public void setFssc(String fssc) {
		this.fssc = fssc;
	}

	public String getLssc() {
		return lssc;
	}

	public void setLssc(String lssc) {
		this.lssc = lssc;
	}

	public String getFhsc() {
		return fhsc;
	}

	public void setFhsc(String fhsc) {
		this.fhsc = fhsc;
	}

	public String getLhsc() {
		return lhsc;
	}

	public void setLhsc(String lhsc) {
		this.lhsc = lhsc;
	}

	

}
