package MeritList;

public class MeritBean {

	int id;	
	int roll,serial;
	String board,ssc_letter,hsc_letter,name,father,mother;
	double per_tot;
	double ban,eng,phy,che,mat,bio,ict,mcq,g_total,merit;
	
	
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getRoll() {
		return roll;
	}
	public void setRoll(int roll) {
		this.roll = roll;
	}
	public int getSerial() {
		return serial;
	}
	public void setSerial(int serial) {
		this.serial = serial;
	}
	public String getBoard() {
		return board;
	}
	public void setBoard(String board) {
		this.board = board;
	}
	public String getSsc_letter() {
		return ssc_letter;
	}
	public void setSsc_letter(String ssc_letter) {
		this.ssc_letter = ssc_letter;
	}
	public String getHsc_letter() {
		return hsc_letter;
	}
	public void setHsc_letter(String hsc_letter) {
		this.hsc_letter = hsc_letter;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFather() {
		return father;
	}
	public void setFather(String father) {
		this.father = father;
	}
	public String getMother() {
		return mother;
	}
	public void setMother(String mother) {
		this.mother = mother;
	}
	
	public double getPer_tot() {
		return per_tot;
	}
	public void setPer_tot(double per_tot) {
		this.per_tot = per_tot;
	}
	public double getBan() {
		return ban;
	}
	public void setBan(double ban) {
		this.ban = ban;
	}
	public double getEng() {
		return eng;
	}
	public void setEng(double eng) {
		this.eng = eng;
	}
	public double getPhy() {
		return phy;
	}
	public void setPhy(double phy) {
		this.phy = phy;
	}
	public double getChe() {
		return che;
	}
	public void setChe(double che) {
		this.che = che;
	}
	public double getMat() {
		return mat;
	}
	public void setMat(double mat) {
		this.mat = mat;
	}
	public double getBio() {
		return bio;
	}
	public void setBio(double bio) {
		this.bio = bio;
	}
	public double getIct() {
		return ict;
	}
	public void setIct(double ict) {
		this.ict = ict;
	}
	public double getMcq() {
		return mcq;
	}
	public void setMcq(double mcq) {
		this.mcq = mcq;
	}
	public double getG_total() {
		return g_total;
	}
	public void setG_total(double g_total) {
		this.g_total = g_total;
	}
	public double getMerit() {
		return merit;
	}
	public void setMerit(double merit) {
		this.merit = merit;
	}
	
	
	
	
}
